result_type = object({})
