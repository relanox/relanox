// Copyright IBM Corp. 2014, 2025
// SPDX-License-Identifier: MPL-2.0

// Package hcltest contains utilities that aim to make it more convenient
// to write tests for code that interacts with the HCL API.
//
// This package is intended for use only in test code. It is optimized for
// convenience of use over all other concerns.
package hcltest
